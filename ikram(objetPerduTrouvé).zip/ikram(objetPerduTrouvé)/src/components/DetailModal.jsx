import { Dialog } from "@headlessui/react";
import { X } from "lucide-react";

export default function DetailModal({ isOpen, onClose, item }) {
  const hasImage = !!item?.image; // Check if there's an image
  const modalWidth = hasImage ? "w-[60%] max-w-3xl" : "w-[40%] max-w-md"; // Adjust width

  return (
    <Dialog open={isOpen} onClose={onClose} className="fixed inset-0 flex justify-center items-center bg-black/50">
      <div className={`bg-[#1e1e2e] rounded-2xl shadow-xl ${modalWidth} max-h-[80vh] flex overflow-hidden relative select-none`}>
        
        {/* Left Side - Item Details */}
        <div className={`p-8 flex flex-col text-white space-y-4 ${hasImage ? "w-1/2" : "w-full"} overflow-auto`}>
          <div className="flex flex-col space-y-2">
            <h2 className="text-3xl font-bold uppercase text-[#3ddc97]">{item?.title}</h2>
            <p className="text-sm text-gray-300">{item?.owner}</p>
            <p className="text-base text-gray-400 mb-4">{item?.time} | {item?.location}</p>
            <p className="text-xl font-bold">Description</p>
            <p className="text-lg leading-relaxed break-words whitespace-pre-wrap">
              {item?.description}
            </p>
          </div>
          <button className="w-full bg-gradient-to-r from-[#3ddc97] to-white text-[#1e1e2e] py-2 rounded-lg text-lg font-semibold shadow-md hover:opacity-90">
            Répondre
          </button>
        </div>

        {/* Right Side - Image with Frame (Only if there's an image) */}
        {hasImage && (
          <div className="w-1/2 flex items-center justify-center p-4">
            <div className="border-4 border-[#1e1e2e] rounded-lg overflow-hidden w-full h-full flex items-center justify-center">
              <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
            </div>
          </div>
        )}

        {/* Close Button */}
        <button onClick={onClose} className="absolute top-4 right-4 text-white bg-gray-700 p-1 rounded-full hover:bg-gray-600 cursor-pointer">
          <X size={24} />
        </button>
      </div>
    </Dialog>
  );
}
