import React from "react";

export default function MyObjectsModal({ isOpen, onClose, items, onMarkAsTraite, darkMode }) {
  if (!isOpen) return null;

  const filteredItems = items.filter(item => !item.traite);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black opacity-30"></div>

      {/* Modal content */}
      <div
        className={`relative z-10 w-[90%] max-w-lg max-h-[80vh] overflow-y-auto p-6 rounded-lg shadow-lg border
        ${darkMode ? "bg-[#1e293b] text-white border-gray-600" : "bg-gray-100 text-gray-900 border-gray-300"}`}
        onClick={e => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-xl font-bold hover:text-red-500"
        >
          ×
        </button>

        <h2 className="text-lg font-semibold mb-4">Mes objets non récupérés</h2>

        {filteredItems.length === 0 ? (
          <p className="text-sm italic">Aucun objet à récupérer.</p>
        ) : (
          <ul className="space-y-4">
            {filteredItems.map((item, index) => (
              <li
                key={index}
                className={`p-4 rounded-lg shadow-sm border 
                ${darkMode ? "bg-[#334155] text-white border-gray-500" : "bg-white text-gray-800 border-gray-200"}`}
              >
                <h3 className="font-bold text-base">{item.title}</h3>
                <p className="text-sm">{item.description}</p>
                <p className="text-sm mt-1 text-gray-400">
                  {item.type === "perdu" ? "Perdu" : "Trouvé"} à {item.location} le {item.time}
                </p>
                <button
                  onClick={() => onMarkAsTraite(items.indexOf(item))}
                  className="mt-3 px-3 py-1 text-sm font-semibold rounded-md
                  bg-emerald-500 hover:bg-emerald-600 text-white"
                >
                  Marquer comme récupéré
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
