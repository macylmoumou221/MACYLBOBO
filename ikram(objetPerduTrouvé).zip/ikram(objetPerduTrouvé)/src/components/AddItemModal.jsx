import { Dialog } from "@headlessui/react";
import { X } from "lucide-react";

export default function AddItemModal({ isOpen, onClose, newItem, setNewItem, onAdd, darkMode }) {

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewItem({ ...newItem, image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const currentDate = new Date().toISOString().split("T")[0];

  const handleDateChange = () => {
    setNewItem({ ...newItem, time: currentDate });
  };

  return (
    <Dialog open={isOpen} onClose={onClose} className="fixed inset-0 z-50">
    {/* Overlay clair/sombre */}
    <div className="fixed inset-0 bg-white/40 dark:bg-black/40 backdrop-blur-sm" aria-hidden="true" />
  
    {/* Contenu du modal */}
    <div className="fixed inset-0 flex items-center justify-center">
      <div className="relative bg-white dark:bg-[#1e1e2e] text-[#1e1e2e] dark:text-white p-6 rounded-xl shadow-xl w-[90%] max-w-3xl select-none transition-all">
        {/* Bouton de fermeture */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 dark:text-gray-300 hover:text-gray-700 dark:hover:text-white"
        >
          <X size={24} />
        </button>
  
        <h2 className="text-xl font-bold mb-4 text-center">Objet trouvé/perdu</h2>
  
        {/* Select Type */}
        <select
          className="w-full p-2 mb-2 rounded border border-gray-300 dark:border-gray-600 bg-[#f4f7f9] dark:bg-[#2a2a3d] text-sm focus:outline-none focus:border-[#A0E6D7] focus:ring-2 focus:ring-[#A0E6D7]"
          onChange={(e) => setNewItem({ ...newItem, type: e.target.value })}
        >
          <option value="">Sélectionner...</option>
          <option value="perdu">Perdu</option>
          <option value="trouvé">Trouvé</option>
        </select>
  
        {/* Title */}
        <input
          type="text"
          placeholder="L'objet"
          className="w-full p-2 mb-2 rounded border border-gray-300 dark:border-gray-600 bg-[#f4f7f9] dark:bg-[#2a2a3d] text-sm placeholder-gray-500 dark:placeholder-gray-400"
          onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
        />
  
        {/* Description */}
        <textarea
          placeholder="Description"
          className="w-full p-2 mb-2 rounded border border-gray-300 dark:border-gray-600 bg-[#f4f7f9] dark:bg-[#2a2a3d] text-sm placeholder-gray-500 dark:placeholder-gray-400"
          onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
        />
  
        {/* Lieu */}
        <input
          type="text"
          placeholder="Lieu"
          className="w-full p-2 mb-2 rounded border border-gray-300 dark:border-gray-600 bg-[#f4f7f9] dark:bg-[#2a2a3d] text-sm placeholder-gray-500 dark:placeholder-gray-400"
          onChange={(e) => setNewItem({ ...newItem, location: e.target.value })}
        />
  
        {/* Image */}
        <input
          type="file"
          accept="image/*"
          className="w-full p-2 mb-2 rounded border border-gray-300 dark:border-gray-600 bg-[#f4f7f9] dark:bg-[#2a2a3d] text-sm file:mr-4 file:py-1 file:px-2 file:rounded file:border-0 file:bg-[#e5e7eb] file:text-gray-700 dark:file:bg-[#44465a] dark:file:text-white"
          onChange={handleImageChange}
        />
  
        {/* Date cachée */}
        <input type="hidden" value={currentDate} onChange={handleDateChange} />
  
        {/* Bouton Ajouter */}
        <button
          onClick={onAdd}
          className="w-full mt-2 p-2 rounded font-medium bg-[#1e1e2e] dark:bg-[#A0E6D7] text-white dark:text-[#1e1e2e] hover:opacity-90 transition"
        >
          Ajouter
        </button>
      </div>
    </div>
  </Dialog>
  
  );
}
