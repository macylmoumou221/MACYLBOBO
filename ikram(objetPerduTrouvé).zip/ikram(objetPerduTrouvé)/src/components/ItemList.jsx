export default function ItemList({ items, onSelect, darkMode }) {
  if (items.length === 0) {
    return (
      <div className="text-center text-gray-500 mt-10">
        Aucun objet à afficher.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {items.map((item, index) => (
        <div
          key={index}
          onClick={() => !item.traite && onSelect(item)}
          className={`
            flex items-center justify-between 
            p-3 rounded-2xl shadow-sm cursor-pointer transition hover:shadow-md item-style
            ${darkMode 
              ? "bg-[#1e1e2e] text-white" 
              : "bg-white text-[#1e1e2e]"}
            ${item.traite ? "opacity-50 pointer-events-none" : ""}
          `}
        >
          <div className="flex-1">
            <h3 className={`text-sm font-semibold ${item.traite ? "line-through" : ""}`}>
              {item.title}
            </h3>
            <p className="text-xs truncate mt-1">
              {item.description}
            </p>
            <div className="flex gap-3 mt-1 text-[11px]">
              <span className={darkMode ? "text-gray-400" : "text-gray-500"}>
                📍 {item.location}
              </span>
              <span className={darkMode ? "text-gray-400" : "text-gray-500"}>
                📅 {item.time}
              </span>
            </div>
          </div>

          <span
            className={`
              px-2.5 py-1 text-[11px] rounded-full whitespace-nowrap
              ${item.type === "perdu"
                ? darkMode
                  ? "bg-red-800 text-red-300"
                  : "bg-red-100 text-red-500"
                : darkMode
                  ? "bg-green-800 text-green-300"
                  : "bg-green-100 text-green-500"
              }
            `}
          >
            {item.type.toUpperCase()}
          </span>
        </div>
      ))}
    </div>
  );
}
