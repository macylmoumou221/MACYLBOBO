export default function LogoutModal({ show, onCancel, onConfirm }) {
  return (
    <div
      className={`fixed inset-0 flex items-center justify-center z-50 transition-opacity duration-300 ${
        show ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
      }`}
    >
      <div className="absolute inset-0 bg-[#514e4e4e] bg-opacity-50 backdrop-blur-sm" />

      <div
        className={`relative bg-white rounded-xl shadow-lg p-6 w-[90%] max-w-md text-center transform transition-transform duration-300 ${
          show ? "scale-100" : "scale-90"
        }`}
      >
        <h2 className="text-xl font-semibold text-gray-800 mb-2">
        ˙◠˙ Se déconnecter ?
        </h2>
        <p className="text-gray-600 mb-6">Es-tu sûre de vouloir te déconnecter ?</p>

        <div className="flex justify-center gap-4">
          <button
            className="px-4 py-2 rounded-md bg-gray-200 text-gray-800 hover:bg-gray-300"
            onClick={onCancel}
          >
            Annuler
          </button>
          <button
            className="px-4 py-2 rounded-md bg-[#3ddc97] text-white hover:bg-[#35c388]"
            onClick={onConfirm}
          >
            Confirmer
          </button>
        </div>
      </div>
    </div>
  );
}
