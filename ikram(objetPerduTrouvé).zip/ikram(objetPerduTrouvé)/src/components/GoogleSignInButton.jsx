// import { GoogleLogin } from "@react-oauth/google";
// import { FcGoogle } from "react-icons/fc";
// import { GoogleLogin } from "@react-oauth/google";

// export default function GoogleSignInButton({ onSuccess }) {
//   return (
//     <div className="w-full flex items-center justify-center bg-gray-700 rounded-lg hover:bg-gray-800 transition">
//       <div className="flex items-center justify-center gap-2 py-2 px-4">
//         <FcGoogle size={20} />
//         <GoogleLogin
//           onSuccess={onSuccess}
//           onError={() => console.log("Login Failed")}
//           theme="outline"
//           text="signin_with"
//           shape="pill"
//           size="medium"
//           width="250"
//         />
//       </div>
//     </div>
//   );
// }
import { FcGoogle } from "react-icons/fc";
import { googleLogout, useGoogleLogin } from '@react-oauth/google';

export default function GoogleSignInButton({ onSuccess, buttonText }) {
  const login = useGoogleLogin({
    onSuccess,
    onError: () => console.log("Login Failed"),
  });

  return (
    <button
      onClick={() => login()}
      className="w-full flex items-center justify-center gap-2 bg-gray-700 py-2 rounded-lg text-white font-bold hover:bg-gray-800 cursor-pointer"
    >
      <FcGoogle size={20} /> {buttonText}
    </button>
  );
}
