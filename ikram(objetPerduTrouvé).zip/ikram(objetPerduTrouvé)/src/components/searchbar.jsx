import { useEffect, useState } from "react";
import { Search, ArrowRight, GraduationCap } from "lucide-react";
import { LuBriefcaseBusiness } from "react-icons/lu"

export default function Searchbar({ username, isOpen, darkMode, userType,name }) {
  const [isFocused, setIsFocused] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(-1);

  const dummyData = [
    { id: 1, name: "Ikram Khaled", type: "student" },
    { id: 2, name: "sidali bousla", type: "teacher" },
    { id: 3, name: "Sara ouellabi", type: "student" },
    { id: 4, name: "Salima hamidouche", type: "teacher" },
  ];

  useEffect(() => {
    if (query.trim() === "") {
      setResults([]);
      setSelectedIndex(-1);
      return;
    }

    const filtered = dummyData.filter((item) =>
      item.name.toLowerCase().includes(query.toLowerCase())
    );

    setResults(filtered);
    setSelectedIndex(0); // auto sélectionner le premier
  }, [query]);

  const handleSelectResult = (name) => {
    setQuery(name);
    setResults([]);
    setSelectedIndex(-1);
  };

  const handleKeyDown = (e) => {
    if (results.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) =>
        prev < results.length - 1 ? prev + 1 : 0
      );
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) =>
        prev > 0 ? prev - 1 : results.length - 1
      );
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (selectedIndex >= 0 && selectedIndex < results.length) {
        handleSelectResult(results[selectedIndex].name);
      }
    }
  };

  return (
    <header
      className={`fixed top-0 right-0 h-16 select-none shadow-[0_4px_10px_rgba(0,0,0,0.1)]
        flex items-center justify-between px-6 transition-all duration-300 
        ${darkMode ? "bg-[#1f2937] text-white" : "bg-white text-gray-800"}
        ${isOpen ? "w-[calc(100%-230px)]" : "w-[calc(100%-80px)]"}`}
    >
      <div className="text-lg font-semibold select-none">
        Salut, <span className="text-[#3ddc97]">{username}</span>
      </div>

      <div className="relative w-[50%] ml-6">
        <form
          onSubmit={(e) => e.preventDefault()}
          className={`relative flex items-center px-4 py-2 rounded-lg
            ${darkMode ? "bg-[#232d3ac0] text-white" : "bg-gray-100 text-gray-600"}`}
        >
          <Search className="absolute left-3 text-gray-400" size={20} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isFocused ? "" : "Rechercher sur ECHO"}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setTimeout(() => setIsFocused(false), 200)}
            onKeyDown={handleKeyDown}
            className={`bg-transparent focus:outline-none pl-10 w-full
              ${darkMode
                ? "text-white placeholder-transparent md:placeholder-gray-400"
                : "text-gray-600 placeholder-transparent md:placeholder-gray-400"
              }`}
          />
          <button
            type="submit"
            className="flex items-center gap-2 bg-[#3ddc97] text-white px-4 py-2 rounded-lg h-full transition-all cursor-pointer"
          >
            <span className="hidden md:inline">Rechercher</span>
            <ArrowRight size={16} />
          </button>
        </form>

        {isFocused && results.length > 0 && (
          <div className="absolute top-full mt-1 w-full bg-white shadow-lg rounded-lg max-h-60 overflow-auto z-50">
            {results.map((result, index) => (
              <div
                key={result.id}
                onMouseDown={() => handleSelectResult(result.name)}
                className={`px-3 py-2 flex items-center justify-between cursor-pointer rounded-md
                  ${index === selectedIndex ? "bg-[#3ddc9730]" : "hover:bg-[#3ddc9715]"}`}
              >
                {result.name}
                {result.type === "student" ? (
                  <GraduationCap size={16} className="text-[#3ddc97]" />
                ) : (
                  <LuBriefcaseBusiness size={16} className="text-[#3ddc97]" />
                )}
              </div>
            ))}
          </div>
        )}

        {isFocused && results.length === 0 && query.trim() !== "" && (
          <div className="absolute top-full mt-1 w-full bg-white shadow-md rounded-md p-2 text-gray-600">
            Aucun résultat trouvé 
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 text-gray-500 select-none relative">
        <div className="relative w-10 h-10">
          <img
            src=""
            alt="Profile"
            className="w-10 h-10 object-cover rounded-full bg-gray-300"
          />
          {userType === "teacher" ? (
            <LuBriefcaseBusiness
              size={16}
              className="text-[#3ddc97] absolute bottom-0 right-0 bg-white rounded-full p-[2px]"
            />
          ) : (
            <GraduationCap
              size={16}
              className="text-[#3ddc97] absolute bottom-0 right-0 bg-white rounded-full p-[2px]"
            />
          )}
        </div>
        <span>{name}</span>
      </div>
    </header>
  );
}
