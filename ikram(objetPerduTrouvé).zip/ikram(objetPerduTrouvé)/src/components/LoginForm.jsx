import { useState } from "react";
import { FiMail, FiUser, FiLock } from "react-icons/fi";
import { FcGoogle } from "react-icons/fc";
import PasswordInput from "./PasswordInput";
import { Link } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import GoogleSignInButton from "./GoogleSignInButton";

const LoginForm = () => {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
  const { language } = useLanguage(); // Add this line inside your component


  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <form className="space-y-6 select-none">
    <h1 className="text-2xl text-[#3ddc97] font-bold text-center">{language.login.title}</h1>
    {/* Username Input */}
    <div className="relative border-b border-gray-400">
  <input
    type="text"
    name="username"
    value={formData.username}
    onChange={handleChange}
    className="peer w-full bg-transparent outline-none py-2 pr-8 text-white placeholder-transparent"
    placeholder="Nom d'utilisateur "
    required
  />
  <label
    className="absolute left-0 top-1/2 -translate-y-1/2 text-gray-300 transition-all duration-200 
               peer-focus:top-0 peer-focus:text-sm peer-focus:text-[#3ddc97] 
               peer-not-placeholder-shown:top-0 peer-not-placeholder-shown:text-sm 
               peer-not-placeholder-shown:text-[#3ddc97]"
  >
    {language.login.username}
  </label>
  <FiUser className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-300" />
</div>

  
    {/* Password Input */}
    <PasswordInput value={formData.password} onChange={handleChange} />
  
    
    {/* Buttons */}
    <button className="w-full bg-[#3ddc97] py-2 mt-1 rounded-lg text-white font-bold hover:bg-[#32c587] cursor-pointer">
    {language.login.loginButton}
    </button>
    <button className="w-full flex items-center justify-center gap-2 bg-gray-700 py-2 rounded-lg text-white font-bold hover:bg-gray-800 cursor-pointer">
      <FcGoogle size={20} /> {language.login.googleButton}
    </button>
    <p className="text-center text-[#5E5E61]">
    {language.login.signupPrompt}  {" "}
    <Link to="/signup" className="text-[#2A2A3B] font-bold hover:underline">
          {language.login.signupLink}
        </Link>
</p>

  </form>
  
  );
};

export default LoginForm;
