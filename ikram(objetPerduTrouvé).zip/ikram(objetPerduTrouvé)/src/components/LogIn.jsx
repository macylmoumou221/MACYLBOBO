import LoginForm from "./LoginForm"; 
import { useLanguage } from"../context/LanguageContext";
const LogIn = () => {
  return (
    <div className="flex flex-col md:flex-row items-center justify-center w-full min-h-screen bg-dark relative p-6">
      {/* Background Waves */}
      <div className="absolute inset-0 -z-10 bg-wave-pattern"></div>

      {/* Signup Form */}
      <div className="bg-white/10 backdrop-blur-lg p-6 md:p-8 pr-10 rounded-lg shadow-lg w-full max-w-lg">
        <LoginForm />
      </div>
    </div>
  );
};

export default LogIn;
