import React, { useState } from "react";
import FloatingButton from "./FloatingButton";
import ItemList from "./ItemList";
import AddItemModal from "./AddItemModal";
import DetailModal from "./DetailModal";
import MyObjectsModal from "./MyObjectsModal"; // nouveau composant importé
import historyIcon from "../assets/history.png"; 


export default function LostFoundPage({ darkMode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [showMyItems, setShowMyItems] = useState(false);

  const [items, setItems] = useState([
    {
      type: "trouvé",
      title: "Clé USB noire",
      description: "Clé USB trouvée dans la salle B204, capacité 16Go",
      image: null,
      location: "Bâtiment B",
      time: "2025-04-21",
      traite: false,
    },
    {
      type: "perdu",
      title: "Portefeuille en cuir",
      description: "Portefeuille perdu près de la cafétéria, contient une carte d’étudiant",
      image: null,
      location: "Cafétéria",
      time: "2025-04-20",
      traite: false,
    },
  ]);

  const [newItem, setNewItem] = useState({
    type: "",
    title: "",
    description: "",
    image: null,
    location: "",
    time: ""
  });

  const [selectedItem, setSelectedItem] = useState(null);
  const [typeFilter, setTypeFilter] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [timeFilter, setTimeFilter] = useState("");

  const handleAddItem = () => {
    if (!newItem.title || !newItem.description) return;
    const today = new Date().toISOString().split("T")[0];
    setItems([...items, { ...newItem, time: today, traite: false }]);
    setNewItem({ type: "", title: "", description: "", image: null, location: "", time: "" });
    setIsOpen(false);
  };

  const markAsTraite = (index) => {
    const updatedItems = [...items];
    updatedItems[index].traite = true;
    setItems(updatedItems);
  };

  const filteredItems = items.filter(item => {
    const matchesType = typeFilter ? item.type === typeFilter : true;
    const matchesLocation = locationFilter ? item.location.toLowerCase().includes(locationFilter.toLowerCase()) : true;
    const matchesTime = timeFilter ? item.time === timeFilter : true;
    return matchesType && matchesLocation && matchesTime;
  });

  return (
    <div className="relative p-8 pt-20 select-none">
      <FloatingButton onClick={() => setIsOpen(true)} />

      {/* Popup Mes Objets (nouvelle version propre) */}
      <AddItemModal
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  newItem={newItem}
  setNewItem={setNewItem}
  onAdd={handleAddItem}
  darkMode={darkMode}  // ← AJOUTE CETTE LIGNE
/>

{/* Bouton "Mes objets" avec l'icône et le texte à gauche */}
<div className="flex justify-start mb-4">
  <button
    onClick={() => setShowMyItems(true)}
    className={`
      flex items-center gap-2 font-semibold text-sm transition
      ${darkMode ? "text-[#3ddc97] hover:text-[#82d2b0]" : "text-[#3ddc97] hover:text-[#2cb68c]"}
    `}
  >
    <img src={historyIcon} alt="History" className="w-5 h-5" />
    Mes objets
  </button>
</div>

      {/* Section Filtres */}
      <div className="flex justify-between items-center mb-4">
        <div className="w-1/3 mr-2">
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="w-full p-2 rounded-md bg-[#f4f7f9] text-[#1e1e2e] 
                       dark:bg-[#1f2937] dark:text-white 
                       focus:outline-none focus:ring-2 focus:ring-[#A0E6D7] text-sm select"
          >
            <option value="">Tout</option>
            <option value="perdu">Perdu</option>
            <option value="trouvé">Trouvé</option>
          </select>
        </div>
        <div className="w-1/3 mx-2">
          <input
            type="text"
            placeholder="Lieu"
            value={locationFilter}
            onChange={e => setLocationFilter(e.target.value)}
            className="w-full p-2 rounded-md bg-[#f4f7f9] text-[#101012]
                       dark:bg-[#3c3c50] dark:text-white
                       focus:outline-none focus:ring-2 focus:ring-[#A0E6D7] text-sm input-style"
          />
        </div>
        <div className="w-1/3 ml-2">
          <input
            type="date"
            value={timeFilter}
            onChange={e => setTimeFilter(e.target.value)}
            className="w-full p-2 rounded-md bg-[#f4f7f9] text-[#1e1e2e]
                       dark:bg-[#3c3c50] dark:text-white
                       focus:outline-none focus:ring-2 focus:ring-[#A0E6D7] text-sm input-style"
          />
        </div>
      </div>

      {/* Liste des items filtrés */}
      <div className="mt-6">
        <ItemList
          items={filteredItems}
          onSelect={(item) => {
            if (!item.traite) {
              setSelectedItem(item);
              setIsDetailOpen(true);
            }
          }}
          darkMode={darkMode}
        />
      </div>

      {/* Modals */}
      <AddItemModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        newItem={newItem}
        setNewItem={setNewItem}
        onAdd={handleAddItem}
      />
      <DetailModal
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        item={selectedItem}
      />
      <MyObjectsModal
  isOpen={showMyItems}
  onClose={() => setShowMyItems(false)}
  items={items}
  onMarkAsTraite={markAsTraite}
  darkMode={darkMode}
/>

    </div>
  );
}
