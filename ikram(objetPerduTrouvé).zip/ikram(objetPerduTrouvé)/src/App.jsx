import React, { useState, useEffect } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Searchbar from "./components/Searchbar";
import LostFoundPage from "./components/LostFoundPage";

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    const saved = localStorage.getItem("sidebarOpen");
    if (saved !== null) return saved === "true";
    return window.innerWidth >= 1024;
  });

  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("darkMode") === "true";
  });

  const navigate = useNavigate();

  useEffect(() => {
    localStorage.setItem("sidebarOpen", sidebarOpen);
  }, [sidebarOpen]);

  
  useEffect(() => {
    const handleResize = () => {
    
      setSidebarOpen(window.innerWidth >= 1024);
    };
    window.addEventListener("resize", handleResize);
    handleResize(); 
    return () => window.removeEventListener("resize", handleResize);
  }, []);


  useEffect(() => {
    localStorage.setItem("darkMode", darkMode);
    document.body.classList.toggle("dark", darkMode);
  }, [darkMode]);


  const handleLogout = () => {
    localStorage.removeItem("userToken");
    navigate("/login");
  };

  return (
    <div
      className={`flex flex-col h-screen ${
        darkMode ? "bg-[#2A2A3B] text-white" : "bg-white text-[#2A2A3B]"
      }`}
    >
      <div className="flex flex-1">
    
        <Sidebar expanded={sidebarOpen} setExpanded={setSidebarOpen} />

      
        <main
          className={`flex-1 transition-all duration-300 ${
            sidebarOpen ? "ml-[230px]" : "ml-[80px]"
          }`}
        >
       
          <div className="px-6 pt-6 flex justify-between items-center">
            <Searchbar
              isOpen={sidebarOpen}
              username="Ikram"
              darkMode={darkMode}
              userType="student" 
              name="ikram Khaled"
            />
          
          </div>

         
          <div className="pt-6 px-6">
            <Routes>
            <Route path="/objet-trouver" element={<LostFoundPage darkMode={darkMode} />} />

              
            </Routes>
          </div>
          <div className="p-6 flex justify-center">
            <button
              onClick={() => setDarkMode((p) => !p)}
              className="px-4 py-2 rounded-lg bg-[#3ddc97] text-white hover:bg-[#2cb581] transition"
            >
              {darkMode ? "Mode clair " : "Mode sombre "}
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
